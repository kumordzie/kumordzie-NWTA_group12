package com.example.inventory;

import java.net.URL;
import java.util.ResourceBundle;

public interface initializable {
    void initialize(URL url, ResourceBundle resourceBundle);
}
